### Execute ###

To run the web page, execute app/app.py in terminal or any other IDE, then enter localhost:5000/ in your browser. By doing so, you should see our visualization web page.