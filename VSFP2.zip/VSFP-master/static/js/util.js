function getExtentWithNaN(array) {
	var min = Infinity, max = 0;

	for (var i = 0; i < array.length; i++) {
		if (!isNaN(array[i])) {
			min = Math.min(min, array[i]);
			max = Math.max(max, array[i]);
		}
	}

	return [min, max];
}

function encode2Name(encode) {
	switch (encode) {
		case "year":
			return "Year";

		// economy
		case "NY.GDP.PCAP.CD":
			return "GDP (USD per cap.)";
		case "NY.GNP.PCAP.CD":
			return "GNI (USD per cap.)";
		case "NY.GDP.MKTP.CD":
			return "GDP (US$)"

		// population
		case "SP.POP.TOTL":
			return "Population";
		case "SP.DYN.CBRT.IN":
			return "Birth Rate (%)";
		case "SP.DYN.LE00.IN":
			return "Life Expectancy (years)";
		case "SM.POP.TOTL":
			return "Migrant";
		case "SP.POP.GROW":
			return "Population growth (%)"
		case "SP.DYN.CDRT.IN":
			return "Death Rate (%)";
 
		// energy
		case "EN.ATM.CO2E.KT":
			return "CO2 Eemission (kt)";
		case "EN.CO2.TRAN.ZS":
			return "CO2 (transportation) (%)";
		case "EN.CO2.MANF.ZS":
			return "CO2 (manufacturing ind.) (%)";
		case "EN.CO2.ETOT.ZS":
			return "CO2 (power production) (%)";
		case "EN.CO2.BLDG.ZS":
			return "CO2 (commercial bldg.)"
		case "EG.USE.COMM.CL.ZS":
			return "Alter. Energy (%)";

		// edu
		case "SE.PRE.ENRR":
			return "Enrollment (preprimary) (%)";
		case "SE.PRM.NENR":
			return "Enrollment (primary) (%)";
		case "SE.SEC.ENRR":
			return "Enrollment (secondary) (%)";
		case "SE.TER.ENRR":
			return "Enrollment (tertiary) (%)";
		case "SE.XPD.TOTL.GD.ZS":
			return "Gov. expenditure (% of GDP)";
	}
}

function update_html (val) {
	if (val == "economy") {
		$("#subtopicSelect").html(" \
			<option value='gdp' selected='selected'>GDP</option> \
			<option value='gni'>GNI per capita</option> \
		");
	}
	else if (val == "energy") {
		$("#subtopicSelect").html(" \
			<option value='co2_emission' selected='selected'>CO2 emission (kt)</option> \
			<option value='co2_tran'>CO2 emission from transportation (%)</option> \
			<option value='co2_manf'>CO2 emission from manufacturing industries (%)</option> \
			<option value='co2_elec'>CO2 emission electricity and heat production (%)</option> \
			<option value='co2_bldg'>CO2 emission residental and commercial building (%)</option> \
			<option value='alternative'>alternative energy usage rate (%)</option> \
		");
	}
	else if (val == "population") {
		$("#subtopicSelect").html(" \
			<option value='population' selected='selected'>Population</option> \
			<option value='migrant'>Migrant (people)</option> \
			<option value='birth_rate'>Birth Rate (%)</option> \
			<option value='death_rate'>Death Rate (%)</option> \
			<option value='life_expectancy'>Life Expectancy (year)</option> \
		");
	}		
	else if (val == "education") {
		$("#subtopicSelect").html(" \
			<option value='gov_expenditure' selected='selected'>Government expenditure on edu. (US$)</option> \
			<option value='enroll_preprimary'>School enrollment, preprimary (%)</option> \
			<option value='enroll_primary'>School enrollment, primary (%)</option> \
			<option value='enroll_secondary'>School enrollment, secondary (%)</option> \
			<option value='enroll_tertiary'>School enrollment, tertiary (%)</option> \
		");
	}
}